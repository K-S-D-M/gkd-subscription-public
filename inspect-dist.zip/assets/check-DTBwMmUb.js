var e=(e,t)=>{try{return new URL(e,t)}catch{}};export{e as t};
//# sourceMappingURL=check-DTBwMmUb.js.map